package com.example.unip_mobile_2026;

import android.app.Activity;
import android.os.Bundle;
import android.widget.Button;
import android.widget.Toast;
import android.content.Intent;

public class MenuActivity extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu);

        Button cadastro = findViewById(R.id.btnCadastro);
        Button consultar = findViewById(R.id.btnConsultar);
        Button configuracoes = findViewById(R.id.btnConfiguracoes);
        Button sair = findViewById(R.id.btnSair);

        cadastro.setOnClickListener(v ->
            Toast.makeText(this, R.string.r4_msg_cadastro, Toast.LENGTH_SHORT).show());
        consultar.setOnClickListener(v ->
            Toast.makeText(this, R.string.r4_msg_consultar, Toast.LENGTH_SHORT).show());

        configuracoes.setOnClickListener(v -> {

            Toast.makeText(
                    MenuActivity.this,
                    R.string.r4_msg_configuracoes,
                    Toast.LENGTH_SHORT
            ).show();

            // CheckBox do Relatório 5
            Intent intent = new Intent(
                    MenuActivity.this,
                    CheckboxActivity.class
            );

            startActivity(intent);
        });

    }
}
