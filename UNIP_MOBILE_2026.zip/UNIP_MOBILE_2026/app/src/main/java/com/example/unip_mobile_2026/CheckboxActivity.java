package com.example.unip_mobile_2026;

import android.app.Activity;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.text.TextUtils;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

/**
 * Relatório 5: seleção independente com CheckBox.
 * Relatório 6: persistência de nome e preferências com SharedPreferences.
 */
public class CheckboxActivity extends Activity {

    private static final String ARQUIVO_PREFERENCIAS =
            "com.example.unip_mobile_2026.configuracoes";
    private static final String CHAVE_NOME = "nome_usuario";
    private static final String CHAVE_PUSH = "notificacoes_push";
    private static final String CHAVE_EMAIL = "alertas_email";
    private static final String CHAVE_SOM = "sons_notificacao";
    private static final String CHAVE_RESUMO = "resumo_semanal";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_checkbox);

        EditText etNomeLocal = findViewById(R.id.etNomeLocal);
        CheckBox cbPush = findViewById(R.id.cbPush);
        CheckBox cbEmail = findViewById(R.id.cbEmail);
        CheckBox cbSom = findViewById(R.id.cbSom);
        CheckBox cbResumo = findViewById(R.id.cbResumo);
        Button btnVerificar = findViewById(R.id.btnVerificar);
        Button btnSalvarDados = findViewById(R.id.btnSalvarDados);
        TextView tvResultado = findViewById(R.id.tvResultado);
        TextView tvPersistencia = findViewById(R.id.tvPersistencia);

        // Arquivo privado de pares chave-valor pertencente a este aplicativo.
        SharedPreferences preferencias = getSharedPreferences(
                ARQUIVO_PREFERENCIAS, MODE_PRIVATE);

        // Recuperação automática na abertura da tela.
        String nomeSalvo = preferencias.getString(CHAVE_NOME, "");
        etNomeLocal.setText(nomeSalvo);
        cbPush.setChecked(preferencias.getBoolean(CHAVE_PUSH, false));
        cbEmail.setChecked(preferencias.getBoolean(CHAVE_EMAIL, false));
        cbSom.setChecked(preferencias.getBoolean(CHAVE_SOM, false));
        cbResumo.setChecked(preferencias.getBoolean(CHAVE_RESUMO, false));

        if (!nomeSalvo.isEmpty()) {
            tvPersistencia.setText(
                    getString(R.string.r6_nome_recuperado, nomeSalvo));
        }

        // Mantém o comportamento demonstrativo do Relatório 5.
        btnVerificar.setOnClickListener(v -> {
            List<String> selecionadas = new ArrayList<>();
            if (cbPush.isChecked()) selecionadas.add(getString(R.string.r5_push));
            if (cbEmail.isChecked()) selecionadas.add(getString(R.string.r5_email));
            if (cbSom.isChecked()) selecionadas.add(getString(R.string.r5_som));
            if (cbResumo.isChecked()) selecionadas.add(getString(R.string.r5_resumo));

            if (selecionadas.isEmpty()) {
                tvResultado.setText(R.string.r5_nenhuma);
            } else {
                tvResultado.setText(getString(
                        R.string.r5_resultado,
                        TextUtils.join(", ", selecionadas)));
            }
        });

        // Relatório 6: grava o nome e os quatro estados booleanos de uma vez.
        btnSalvarDados.setOnClickListener(v -> {
            String nome = etNomeLocal.getText().toString().trim();
            if (nome.isEmpty()) {
                etNomeLocal.setError(getString(R.string.r6_nome_obrigatorio));
                etNomeLocal.requestFocus();
                return;
            }

            preferencias.edit()
                    .putString(CHAVE_NOME, nome)
                    .putBoolean(CHAVE_PUSH, cbPush.isChecked())
                    .putBoolean(CHAVE_EMAIL, cbEmail.isChecked())
                    .putBoolean(CHAVE_SOM, cbSom.isChecked())
                    .putBoolean(CHAVE_RESUMO, cbResumo.isChecked())
                    .apply();

            tvPersistencia.setText(getString(R.string.r6_dados_salvos, nome));
        });
    }
}
