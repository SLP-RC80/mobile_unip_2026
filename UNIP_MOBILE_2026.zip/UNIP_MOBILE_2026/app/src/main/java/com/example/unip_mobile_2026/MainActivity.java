
package com.example.unip_mobile_2026;

import android.content.Intent;
import android.os.Bundle;
import android.util.Patterns;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        WindowCompat.enableEdgeToEdge(getWindow());
        setContentView(R.layout.activity_main);

        // Componentes da tela de login
        EditText etEmail = findViewById(R.id.etEmail);
        EditText etSenha = findViewById(R.id.etSenha);
        Button btnEntrar = findViewById(R.id.btnEntrar);

        // Relatório 7: área de mensagens de validação
        TextView tvValidacao = findViewById(R.id.tvValidacao);

        // Evento do botão Entrar
        btnEntrar.setOnClickListener(v -> {

            String email = etEmail.getText()
                    .toString().trim();

            String senha = etSenha.getText()
                    .toString();

            StringBuilder erros = new StringBuilder();

            // Limpa as mensagens anteriores
            etEmail.setError(null);
            etSenha.setError(null);
            tvValidacao.setVisibility(View.GONE);

            // =====================================
            // VALIDAÇÃO 1: E-MAIL
            // =====================================

            if (email.isEmpty()) {

                String aviso = getString(
                        R.string.r7_email_obrigatorio
                );

                etEmail.setError(aviso);

                erros.append("• ")
                        .append(aviso)
                        .append("\n");

            } else if (!Patterns.EMAIL_ADDRESS
                    .matcher(email).matches()) {

                String aviso = getString(
                        R.string.r7_email_invalido
                );

                etEmail.setError(aviso);

                erros.append("• ")
                        .append(aviso)
                        .append("\n");
            }

            // =====================================
            // VALIDAÇÃO 2: SENHA
            // =====================================

            if (senha.isEmpty()) {

                String aviso = getString(
                        R.string.r7_senha_obrigatoria
                );

                etSenha.setError(aviso);

                erros.append("• ")
                        .append(aviso)
                        .append("\n");

            } else if (senha.length() < 6) {

                String aviso = getString(
                        R.string.r7_senha_curta
                );

                etSenha.setError(aviso);

                erros.append("• ")
                        .append(aviso)
                        .append("\n");
            }

            // =====================================
            // VALIDAÇÃO 3: RESULTADO
            // =====================================

            if (erros.length() > 0) {

                // Mostra os erros encontrados
                tvValidacao.setText(
                        erros.toString().trim()
                );

                tvValidacao.setVisibility(
                        View.VISIBLE
                );

                // Impede a abertura do menu
                return;
            }

            // =====================================
            // DADOS VÁLIDOS
            // =====================================

            // Oculta mensagens de erro
            tvValidacao.setText("");
            tvValidacao.setVisibility(View.GONE);

            // Confirmação demonstrativa
            Toast.makeText(
                    MainActivity.this,
                    R.string.r7_dados_validos,
                    Toast.LENGTH_SHORT
            ).show();

            // Mantém a navegação do Relatório 4
            Intent intent = new Intent(
                    MainActivity.this,
                    MenuActivity.class
            );

            startActivity(intent);
        });

        // =====================================
        // CONFIGURAÇÃO EDGE-TO-EDGE
        // =====================================

        ViewCompat.setOnApplyWindowInsetsListener(
                findViewById(R.id.main),
                (v, insets) -> {

                    Insets systemBars = insets.getInsets(
                            WindowInsetsCompat.Type.systemBars()
                    );

                    v.setPadding(
                            systemBars.left,
                            systemBars.top,
                            systemBars.right,
                            systemBars.bottom
                    );

                    return insets;
                }
        );
    }
}
