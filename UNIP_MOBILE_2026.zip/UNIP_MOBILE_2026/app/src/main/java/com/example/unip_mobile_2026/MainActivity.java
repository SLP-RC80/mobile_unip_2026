package com.example.unip_mobile_2026;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        WindowCompat.enableEdgeToEdge(getWindow());
        setContentView(R.layout.activity_main);

        android.widget.EditText etEmail =
                findViewById(R.id.etEmail);

        android.widget.EditText etSenha =
                findViewById(R.id.etSenha);

        android.widget.Button btnEntrar =
                findViewById(R.id.btnEntrar);


        btnEntrar.setOnClickListener(v -> {

            String email = etEmail.getText().toString().trim();
            String senha = etSenha.getText().toString();

            if (email.isEmpty() || senha.isEmpty()) {

                android.widget.Toast.makeText(
                        MainActivity.this,
                        "Preencha e-mail e senha.",
                        android.widget.Toast.LENGTH_SHORT
                ).show();

            } else {

                android.widget.Toast.makeText(
                        MainActivity.this,
                        "Login demonstrativo.",
                        android.widget.Toast.LENGTH_SHORT
                ).show();

                // Menu principal do Relatório 4
                startActivity(
                        new android.content.Intent(
                                MainActivity.this,
                                MenuActivity.class
                        )
                );
            }
        });


        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
    }
}